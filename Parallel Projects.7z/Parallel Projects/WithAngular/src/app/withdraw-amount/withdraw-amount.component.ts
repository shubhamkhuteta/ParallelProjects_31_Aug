import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee, Transactions } from '../my-service.service';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {


  isLogin:boolean=true;
  employees:Employee[]=[];
  createdTransaction:Transactions;
  
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  withdrawAmount(data:any){
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    console.log(data)
    this.service.withdrawBalance(caccount_first,cbalance);

    this.createdTransaction=new Transactions(cbalance*4,data.caccount,0,data.cbalance);
    this.service.addTransaction(this.createdTransaction)
  }


  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }
}
