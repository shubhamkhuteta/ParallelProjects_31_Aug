import { Component, OnInit } from '@angular/core';
import { MyServiceService, Transactions } from '../my-service.service';
import { Employee } from '../my-service.service';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  transactions:Transactions[]=[];
  employees:Employee[]=[];
  service:MyServiceService;


  constructor(service:MyServiceService) { 
    this.service=service;
  }

  miniStatement(data:any){
    console.log(data)
    this.transactions=this.service.miniStatement(data.caccount);
    console.log(this.transactions)
  }

  ngOnInit() {
    this.service.fetchTransactions();
    this.employees=this.service.getEmployees();
    console.log(this.employees)
  }

}
