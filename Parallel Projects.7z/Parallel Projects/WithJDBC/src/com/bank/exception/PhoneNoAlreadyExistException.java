package com.bank.exception;

public class PhoneNoAlreadyExistException extends Exception {

	@Override
	public String toString() {
		return "Phone No Already Exist";
	}

}
