package com.bank.exception;

public class AccountNoAlreadyExistException extends Exception {

}
