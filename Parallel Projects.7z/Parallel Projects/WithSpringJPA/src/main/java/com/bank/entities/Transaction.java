package com.bank.entities;

import javax.persistence.*;


@Entity
@Table(name="SpringTransaction")
public class Transaction {
	@Column(name="transactionType",length=20)
	private String transactionType;
	
	
	@Id
	private long transactionId;
	
	@Column(name="Amount" ,length=20)
	private int amount;

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
   @ManyToOne
   @JoinColumn(name="accountNo",referencedColumnName="eAcc")
   private Bank bank;
   
   @Override
public String toString() {
	return "Transaction [transactionType=" + transactionType + ", transactionId=" + transactionId + ", amount=" + amount
			+ ", Account=" + bank.getAccountNo() + ", FromAccount=" + FromAccount + "]";
}

public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}
	@Column(name="fromaccount")
	private Long FromAccount;

	public Long getFromAccount() {
		return FromAccount;
	}

	public void setFromAccount(Long otherAccount) {
		FromAccount = otherAccount;
	}

	
}
