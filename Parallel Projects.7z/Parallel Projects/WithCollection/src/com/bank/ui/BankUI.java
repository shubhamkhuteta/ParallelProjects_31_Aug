package com.bank.ui;

import java.util.Scanner;

import com.bank.services.BankService;
import com.bank.services.BankServiceI;

public class BankUI {

	static BankUI bankUi = new BankUI();
	Scanner scanner = new Scanner(System.in);
	
	BankService bankService= new BankService();

	String customer_name,phone_no,city;
	double balance;
	int pin,account_no, account_no_2; 
	boolean res;

	public static void main(String[] args) {
		
		bankUi.chooseAny();
	}

	public void showMenu() 
	{
		System.out.println("1. Create Account ");
		System.out.println("2. Show Balance ");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Account Statement");
		System.out.println("7. Log out");
		System.out.println("Enter your choice :");
	}

	public void chooseAny() {
		System.out.println("----------Welcome to UI Bank----------");
		int close=0;
		while (close==0) {
			
			showMenu();//
			int input=scanner.nextInt();
			/*int option = getOption(scanner);//6 1
			if (option == -1)
			{
				run = false;
			}*/
			switch (input)//input=1, flow-8
			{
			case 1: {
				try {
					System.out.println("Enter your name : ");
					customer_name=scanner.next();

					System.out.println("Enter your phone no : ");
					phone_no=scanner.next();

					System.out.println("Enter your City : ");
					city=scanner.next();

					System.out.println("Enter your balance : ");
					balance=scanner.nextDouble();

					System.out.println("Set your 4 digit pin : ");
					pin=scanner.nextInt();

					account_no=pin;

					res = bankService.setBankDetails(account_no, customer_name, balance, city, phone_no, pin);
					System.out.println(res);
					if(res==true) {
						System.out.println("Account successfully created !");
					}else {
						System.out.println("Operation failed !!");
					}

				} catch (Throwable e) {
					System.out.println("sorry something went wrong");
				}
				break;
			}
			case 2: {
				System.out.println("Enter Account No. : ");
				account_no=scanner.nextInt();
				balance = bankService.getBalance(account_no);
				System.out.println("Current Balance : "+balance);
				break;
			}
			case 3: {
				System.out.println("Enter Account No. : ");
				account_no=scanner.nextInt();

				res = bankService.validateAccountNo(account_no);
				
				if(res==true) {
					System.out.println("Enter Amount to be deposited : ");
					balance=scanner.nextDouble();

					balance = bankService.DepositAmount(account_no, balance);
					System.out.println("Updated Balance : "+balance);
				}else {
					System.out.println("Something Went Wrong !!");
				}
				break;
			}
			case 4 : {
				System.out.println("Enter Account No. : ");
				account_no=scanner.nextInt();
				
				res = bankService.validateAccountNo(account_no);
				
				if(res==true) {
					System.out.println("Enter Amount to be withdrawn : ");
					double balance1=scanner.nextDouble();
					
				 double bal=bankService.WithdrawAmount(account_no, balance1);
					System.out.println("Updated Balance : "+bal);
				}else {
					System.out.println("Something Went Wrong !!");
				}
				break;
			}
			case 5 : 
				System.out.println("Enter Account No. : ");
				account_no=scanner.nextInt();
				
				res = bankService.validateAccountNo(account_no);
				
				if(res==true) {
					System.out.println("Enter account no. in which you want to transfer : ");
					account_no_2 = scanner.nextInt();
					
					res = bankService.validateAccountNo(account_no_2);
					
					if(res==true) {
						System.out.println("Enter Amount : ");
						double amount = scanner.nextInt();
						
						double fund_result = bankService.fundTransfer(account_no,account_no_2,amount);
						System.out.println("Updated Balance : "+fund_result );
						
					}
				}
				
				break;
			case 6 : 
				break;
			case 7 : 
				System.out.println("You have been successfully logged out");
				System.out.println("Do you want to exit ? press 0 to continue 1 to exit");
				close=scanner.nextInt();
				if(close==0) {
					close=0;
				}else {
					System.exit(0);
				}

			default:{
				System.out.println("Please enter valid choice!");
				
				break;
			}
			}
		}
	}


}

