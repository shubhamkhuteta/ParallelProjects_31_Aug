package com.bank.dao;

import java.util.HashMap;

import com.bank.bean.BankBean;

public class BankDao implements BankDaoI{

	BankBean bankBean;
	BankBean bankBean2;
	double updated_balance_deposit;
	double updated_balance_withdraw;
	HashMap hm ;
	public BankDao() {
		super();
		hm = new HashMap();
	}


	double bal,bal2;

	public boolean checkAccount(String account_no) {
		if(hm.containsKey(account_no)) {
			return false;
		}else 
			return true;

	}


	@Override
	public boolean setBankDetails(String account_no, String customer_name, int balance, String city, String phoneno, int pin) {
		// TODO Auto-generated method stub
		return false;

	}


	public boolean setData(int account_no, BankBean bankBean) {
		hm.put(account_no, bankBean);
		return true;

	}


	public double getBalance(int account_no) {
		double bal = 0;
		if(hm.containsKey(account_no)) {

			bankBean=(BankBean) hm.get(account_no);
			bal= bankBean.getBalance();
		}
		return bal;
	}


	public boolean validateAccountNo(int account_no) {
		if(hm.containsKey(account_no)) {
			return true;
		}else {
			return false;
		}

	}


	public double DepositAmount(int account_no, double balance) {
		System.out.println(balance);
		bankBean=(BankBean)hm.get(account_no);
		bal = bankBean.getBalance();
		updated_balance_deposit = balance+bal;
		bankBean.setBalance(updated_balance_deposit);
		//hm.put(account_no, bankBean);
		return updated_balance_deposit;
	}


	public double WithdrawAmount(int account_no, double balance) {
		
		bankBean=(BankBean)hm.get(account_no);
		bal = bankBean.getBalance();
		
		updated_balance_withdraw= bal-balance;
		bankBean.setBalance(updated_balance_withdraw);
		
		//hm.put(account_no, bankBean);
		return updated_balance_withdraw;
	}


	public double fundTransfer(int account_no, int account_no_2, double amount) {
		
		bankBean=(BankBean)hm.get(account_no);
		bal = bankBean.getBalance();
		
		double update1 = bal-amount;
		bankBean.setBalance(update1);
		
		bankBean2=(BankBean)hm.get(account_no_2);
		bal2 = bankBean2.getBalance();
		
		double update2 = bal2+amount;
		bankBean2.setBalance(update2);
		return update2;
		
	}





}
