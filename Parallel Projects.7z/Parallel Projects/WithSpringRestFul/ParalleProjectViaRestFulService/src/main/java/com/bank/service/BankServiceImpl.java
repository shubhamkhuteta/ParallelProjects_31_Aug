package com.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dao.BankEntityDao;
import com.bank.dao.TransactionEntityDao;
import com.bank.entities.BankEntity;
import com.bank.entities.TransactionEntity;
import com.bank.exception.BankException;

@Service
public class BankServiceImpl implements BankService {

	@Autowired
	BankEntityDao bankDao;

	@Autowired
	TransactionEntityDao transDao;

	public BankEntity createAccount(BankEntity bank) throws BankException {
		if(bank.getBal()==null || bank.getBal()<=0){
			throw new BankException("Balance can not be 0");
		}else {
			bankDao.save(bank);
			return bankDao.findById(bank.getAccNo()).get();
		}
	}

	public BankEntity accountsDetails(Long accNo) throws BankException {
		if(!bankDao.findById(accNo).isPresent()) {
				throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}else{
				return bankDao.findById(accNo).get();
		}
	}

	public Double showBalance(Long accNo) throws BankException {
		if(!bankDao.findById(accNo).isPresent()) {
				throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}else{
			return  bankDao.findById(accNo).get().getBal();
		}
		
	}

	public Double deposit(Long accNo, Double amt) throws BankException {

		Optional<BankEntity> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			BankEntity tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() + amt);
			bankDao.save(tempEntity);
			TransactionEntity trans = new TransactionEntity(accNo, "Deposite", bank.get().getBal(),
					bank.get().getBal() + amt);
			transDao.save(trans);
			return showBalance(accNo);
		} else {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	public Double withdraw(Long accNo, Double amt) throws BankException {
		Optional<BankEntity> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			if(amt>showBalance(accNo)) {
				throw new BankException("Insufficient Balance :-(");
			}else {
				BankEntity tempEntity = bank.get();
				tempEntity.setBal(bank.get().getBal() - amt);
				bankDao.save(tempEntity);
				TransactionEntity trans = new TransactionEntity(accNo, "Withdraw", bank.get().getBal(),bank.get().getBal() - amt);
				transDao.save(trans);
				return showBalance(accNo);	
			}
		} else {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	public Double fundTransfer(Long senderAcc, Double amt, Long reciverAcc) throws BankException {
		Optional<BankEntity> senderAccount = bankDao.findById(senderAcc);
		Optional<BankEntity> reciverAccount = bankDao.findById(reciverAcc);
		if (senderAccount.isPresent() && reciverAccount.isPresent()) {
			
			BankEntity sender = senderAccount.get();
			sender.setBal(senderAccount.get().getBal() - amt);
			bankDao.save(sender);
			
			BankEntity reciver = reciverAccount.get();
			reciver.setBal(reciverAccount.get().getBal() + amt);
			bankDao.save(reciver);
			
			TransactionEntity senderTrans = new TransactionEntity(senderAcc, "Fund Transfer", senderAccount.get().getBal(),senderAccount.get().getBal() - amt);
			transDao.save(senderTrans);
			
			TransactionEntity reciverTrans = new TransactionEntity(reciverAcc, "Fund Recieved", reciverAccount.get().getBal(),amt + reciverAccount.get().getBal());
			transDao.save(reciverTrans);
			
			return showBalance(senderAcc);
		} else {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	public List<TransactionEntity> printTransaction(Long accNo) {

		return transDao.printTransaction(accNo);
	}
}
