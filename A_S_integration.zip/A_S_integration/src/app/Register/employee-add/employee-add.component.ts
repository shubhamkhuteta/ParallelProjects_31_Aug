import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Transactions } from 'src/app/Models/TransactionEntity';
import { Customer } from 'src/app/Models/BankEntity';
import { MyServiceService } from 'src/app/Service/my-service.service';
@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  createdCustomer:Customer;
  createdTransaction:Transactions;
  createdFlag:boolean=false;
  router:Router;
  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }

  d:Customer;

  add(data:any){
    data.caccount=Math.floor(Math.random() * 10) + 4326 
    data.cbalance=3000;
    var customer = this.service.add(data.caccount,data.cname,data.cphone,data.cpassword,data.ccity,data.cbalance);
    customer.subscribe
    (
    data => {
      this.d = data;
      this.service.customers.push(data);
      alert("Welcome to the UnsignedInteger Bank\nYour Account No. is : "+this.d.caccount)
      }
      
    );
    this.createdFlag=true;
    this.router.navigate(['app-employee-list']);
  }

  ngOnInit(){
  }

}
