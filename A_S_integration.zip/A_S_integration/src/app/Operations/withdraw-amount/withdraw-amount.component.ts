import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Models/BankEntity';
import { Transactions } from 'src/app/Models/TransactionEntity';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;
  currentBal:number;
  preBalance:number;
  withdrawn:boolean;
  balance:ShowBalanceComponent;
  

  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  async withdrawAmount(data:any){
    let caccount_first=this.service.loginAccount;
    let cbalance=data.cbalance;
    this.withdrawn=true;

    var w = this.service.showBalance();
    w.subscribe
    (
    (data) => {
      this.preBalance = data;
    }
    )
    

    if(this.preBalance<data.cbalance){
      alert("Insufficient Balance :-(")
    }else{
      var  bal = this.service.withdrawBalance(caccount_first,cbalance);
      bal.subscribe
      (
      (data) => {
        this.currentBal=data;
      },
      (error)=>
      {
        alert("Please enter a valid amount :-(")
      })
    }

  }

  ngOnInit() {
  }
}
