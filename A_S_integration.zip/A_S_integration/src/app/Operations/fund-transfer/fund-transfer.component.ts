import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/app/Models/TransactionEntity';
import { MyServiceService } from 'src/app/Service/my-service.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin:boolean=true;
  service:MyServiceService;
  currentBal:number;
  transferred:boolean
  
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  e:any;

  fundTransfer(data:any){
    let caccount_second=data.caccount_second;
    let caccount_first=this.service.loginAccount;
    let cbalance=data.cbalance;

    if(caccount_first==0){
      alert("Please login first :-)")
    }else if(data.cbalance<=0){
      alert("Please enter a valid amount :-(")
    }else{
      var first = this.service.fundTransfer(caccount_first,caccount_second,cbalance);
      first.subscribe
      ((data) => {
          this.currentBal=data;
          this.transferred=true;
      },(error) =>{
        this.transferred=false;
        alert("Please Enter a Valid Account No.")
      })
    }
  }

  ngOnInit() {
  }

}
