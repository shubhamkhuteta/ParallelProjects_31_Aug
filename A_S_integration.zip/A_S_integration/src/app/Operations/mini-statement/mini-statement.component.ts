import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/TransactionEntity';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/BankEntity';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  transactions:Transactions[]=[];
  service:MyServiceService;


  constructor(service:MyServiceService) { 
    this.service=service;
    this.miniStatement();
  }

  miniStatement(){
    var mini =this.service.miniStatement(this.service.loginAccount);
    mini.subscribe
    (
      data=>
      {
        this.transactions=data;
      }
    );
  }

  ngOnInit() {
  }

}
