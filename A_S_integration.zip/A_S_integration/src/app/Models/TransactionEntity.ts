export class Transactions{
  transNo:number;
  accno:number;
  transType:string;
  previousBal:number;
  currentBal:number;
  
  
      constructor(transNo:number,accno:number,transType:string,previousBal:number,currentBal:number)
      {
        this.transNo=transNo;
        this.accno=accno;
        this.transType=transType;
        this.previousBal=previousBal;
        this.currentBal=currentBal;
      }
  }