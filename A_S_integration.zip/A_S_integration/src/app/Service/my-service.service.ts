import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../Models/BankEntity';
import { Transactions } from '../Models/TransactionEntity';
import { BehaviorSubject, Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  isLogin:boolean=true;
  customers:Customer[]=[];
  fetched:boolean=false;
  fetchedT:boolean=false;
  tempCust:any;
  cbalance:number;
  loginAccount:number=0;
  
  private check = new BehaviorSubject('');
  currentMessage = this.check.asObservable();
  private baseUrl = 'http://localhost:5052/BankApplication/viewAll';  

  changeMessage(message: string) {
    this.check.next(message)
  }

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchCustomers();
  }

  fetchCustomers()
  {
    this.http.get(this.baseUrl)
    .subscribe
    (
      data=>
      {
        this.tempCust=data;
        this.convert(data);
      }
    );
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Customer(o.caccount,o.cname,o.cphone,o.cpassword,o.ccity,o.cbalance);
      this.customers.push(e);
    }
  }

  getCustomers():Customer[]
  {
    return this.customers;
  }

  fundTransfer(caccount_first:number,caccount_second:number,cbalance:number):Observable<any>{
    return this.http.put("http://localhost:5052/BankApplication/FundTransfer/"
    +caccount_first+"/"+cbalance+"/"+caccount_second,null)
  }

  miniStatement(caccount:number):Observable<any>{ 
     return this.http.get("http://localhost:5052/BankApplication/MiniStatement/"+caccount)
  }

  add(caccount:number,cname:string,cphone:number,cpassword:string,ccity:string,cbalance:number):Observable<any>{
  var obj = {
	  "cname":cname,
	  "cbalance":cbalance,
	  "cpassword":cpassword,
    "cphone":cphone,
    "ccity":ccity
  }
    return this.http.post("http://localhost:5052/BankApplication/CreateAccount", obj)
  }

  showBalance():Observable<any>{
    return this.http.get("http://localhost:5052/BankApplication/ShowBalance/"+this.loginAccount)
  }

  depositeBalance(caccount:number,cbalance:number):Observable<any>{
      return this.http.put("http://localhost:5052/BankApplication/DepositAmount/"
      + caccount + "/" + cbalance,this.customers)
  }
  
  withdrawBalance(caccount:number,cbalance:number):Observable<any>{
      return this.http.put("http://localhost:5052/BankApplication/WithdrawAmount/"
      + caccount + "/" + cbalance,this.customers)
  }
 
  login(data:Customer):boolean
  {
    //this.fetchCustomers();
    this.customers=this.getCustomers();

    this.loginAccount=data.caccount;
    let cpassword=data.cpassword;

    for(let a of this.customers)
    {
      if(this.loginAccount == a.caccount && cpassword == a.cpassword)
      {
        alert("Login Successful!!\nWelcome to UnsignedInteger Bank :-)")
        this.isLogin=!this.isLogin;
        this.changeMessage('loginhai');
        return true;
      }else {
        continue;
      }
      
    }
    return false; 
  }
 
}

