import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { EmployeeAddComponent } from './Register/employee-add/employee-add.component';
import { EmployeeListComponent } from './Login/employee-list/employee-list.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MyServiceService } from './Service/my-service.service';
import { ShowBalanceComponent } from './Operations/show-balance/show-balance.component';
import { DepositeAmountComponent } from './Operations/deposite-amount/deposite-amount.component';
import { WithdrawAmountComponent } from './Operations/withdraw-amount/withdraw-amount.component';
import { FundTransferComponent } from './Operations/fund-transfer/fund-transfer.component';
import { MiniStatementComponent } from './Operations/mini-statement/mini-statement.component';
import { HomepageComponent } from './HomePage/homepage.component';


@NgModule({
  declarations: [
    AppComponent,
    EmployeeAddComponent,
    EmployeeListComponent,
    ShowBalanceComponent,
    DepositeAmountComponent,
    WithdrawAmountComponent,
    FundTransferComponent,
    MiniStatementComponent,
    HomepageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
