import { Component, OnInit, APP_INITIALIZER, ɵConsole } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/TransactionEntity';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/BankEntity';
import { Alert } from 'selenium-webdriver';
import { SelectorMatcher } from '@angular/compiler';

@Component({
  selector: 'app-deposite-amount',
  templateUrl: './deposite-amount.component.html',
  styleUrls: ['./deposite-amount.component.css']
})
export class DepositeAmountComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;

  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }
 

 
  depositeAmount(data:any){
    // let tid=Math.floor(Math.random() * 21) + 6582 ;
    let caccount_first=this.service.loginAccount;
  
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Deposit Amount"

    var  bal = this.service.depositeBalance(caccount_first,cbalance);
    bal.subscribe
    (
    (data) => {
      alert("Updated Balance : "+data)
        this.service
        this.service.convert(data);
        alert(cbalance)
    }
    )
    // this.createdTransaction=new Transactions(tid,caccount_first,0,cbalance,ttype);
    // this.service.addTransaction(this.createdTransaction)
  }
  
  
  ngOnInit() {
    this.customers=this.service.getCustomers();
  }

}
