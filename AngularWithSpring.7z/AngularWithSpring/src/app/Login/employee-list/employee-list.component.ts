import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/BankEntity';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})

export class EmployeeListComponent implements OnInit {

  service:MyServiceService;
  router:Router;

    message:string;
    newMessage() {
      this.service.changeMessage("login")
    }

  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  customers:Customer[]=[];
  isLogin:boolean=true;

  login(data:any){
this.customers=this.service.getCustomers();
    if(this.service.login(data)){
      this.isLogin=this.service.isLogin;
      this.router.navigate(['app-homepage']);
    }else{
      alert("Values does not matched!")
    }
  }

  ngOnInit() {
    this.service.fetchCustomers();
    this.customers=this.service.getCustomers();
    this.service.currentMessage.subscribe(message => this.message = message)
  }
}
